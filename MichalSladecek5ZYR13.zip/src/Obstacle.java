import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class Obstacle extends User {
    private Image img;

    public Obstacle(int i, int j) {
        super(i, j);

        URL locate = this.getClass().getResource("suitableLocation.png");
        ImageIcon ImgIcon = new ImageIcon(locate);
        Image img = ImgIcon.getImage();
        this.setImage(img);
    }
}
