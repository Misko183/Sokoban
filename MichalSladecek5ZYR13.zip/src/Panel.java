import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import javax.swing.JButton;
import javax.swing.JPanel;

import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;

public class Panel extends JPanel {
    private static final long serialVersionUID = 1L;
    private final int OFFSET = 30;
    private JButton btn1;
    private JButton btn2;
    private JButton btn3;
    private JButton btn4;
    private JButton btn5;
    private JButton btn6;
    private JButton btn7;
    private final int SPACE = 20;
    private final int LEFT_COLLISION = 1;
    private final int RIGHT_COLLISION = 2;
    private final int TOP_COLLISION = 3;
    private final int BOTTOM_COLLISION = 4;
    private ArrayList<Obstacle> obs = new ArrayList<>();
    private ArrayList<Crate> crates = new ArrayList<>();
    private ArrayList<SuitableLocation> SuitLo = new ArrayList<SuitableLocation>();
    private int w = 0;
    private int h = 0;
    private boolean solved = false;
    private PlayerCharacter PlayerChar;
    private String stage =
              "    ######\n"
            + "    ##   #\n"
            + "    ##$ $#\n"
            + "  ####   ##\n"
            + "  ##   $  #\n"
            + "#### # ## #   ######\n"
            + "##   # ## #####  ..#\n"
            + "## $  $          .$#\n"
            + "###### ### #@##  ..#\n"
            + "    ##     #########\n"
            + "    ########\n";

    public Panel() {
        addKeyListener(new TAdapter());
        setFocusable(true);
        initWorld();
    }
    public int getBoardWidth() {
        return this.w;
    }

    public int getBoardHeight() {
        return this.h;
    }

    public final void initWorld() {
        btn1 = new JButton("Level 1");
        btn1.setBounds(10000, 1000, 200, 50);
        this.add(btn1);
        Font f = new Font("Courier", Font.LAYOUT_LEFT_TO_RIGHT, 24);

        btn2 = new JButton("Level 2");
        btn2.setBounds(10000, 1055, 200, 50);
        this.add(btn2);
        Font g = new Font("Courier", Font.LAYOUT_LEFT_TO_RIGHT, 24);

        btn3 = new JButton("Level 3");
        btn3.setBounds(10000, 1110, 200, 50);
        this.add(btn3);
        Font n = new Font("Courier", Font.LAYOUT_LEFT_TO_RIGHT, 24);

        btn4 = new JButton("Level 4");
        btn4.setBounds(500, 1165, 200, 50);
        this.add(btn4);
        Font m = new Font("Courier", Font.LAYOUT_LEFT_TO_RIGHT, 24);

        btn5 = new JButton("Level 5");
        btn5.setBounds(500, 1220, 200, 50);
        this.add(btn5);
        Font j = new Font("Courier", Font.LAYOUT_LEFT_TO_RIGHT, 24);

        btn6 = new JButton("Steps");
        btn6.setBounds(500, 1275, 200, 50);
        this.add(btn6);
        Font k = new Font("Courier", Font.LAYOUT_LEFT_TO_RIGHT, 24);

        btn7 = new JButton("Exit");
        btn7.setBounds(500, 1330, 200, 50);
        this.add(btn7);
        Font l = new Font("Courier", Font.LAYOUT_LEFT_TO_RIGHT, 24);

        int x = OFFSET;
        int y = OFFSET;

        Obstacle wall;
        Crate b;
        SuitableLocation a;

        for(int i = 0; i < stage.length(); i++){
            char item = stage.charAt(i);

            if(item == '\n'){
                y += SPACE;

                if(this.w < x){
                    this.w = x;
                }

                x = OFFSET;
            } else if(item == '#'){
                wall = new Obstacle(x, y);
                obs.add(wall);
                x += SPACE;
            } else if(item == '$'){
                b = new Crate(x, y);
                crates.add(b);
                x += SPACE;
            } else if(item == '.'){
                a = new SuitableLocation(x, y);
                SuitLo.add(a);
                x += SPACE;
            } else if(item == '@'){
                PlayerChar = new PlayerCharacter(x, y);
                x += SPACE;
            } else if(item == ' '){
                x += SPACE;
            }

            h = y;
        }
    }

    public void buildWorld(Graphics g) {
        g.setColor(new Color(0, 108, 209));
        g.fillRect(0, 0, this.getWidth(), this.getHeight());

        ArrayList<User> world = new ArrayList<User>();
        world.addAll(obs);
        world.addAll(SuitLo);
        world.addAll(crates);
        world.addAll(Collections.singleton(PlayerChar));

        for (int i = 0; i < world.size(); i++) {
            User item = (User) world.get(i);

            if ((item instanceof PlayerCharacter) || (item instanceof Crate)) {
                g.drawImage(item.getImage(), item.x() + 2, item.y() + 2, this);
            } else {
                g.drawImage(item.getImage(), item.x(), item.y(), this);
            }

            if (solved) {
                g.setColor(new Color(255, 255, 255));
                g.drawString("The level has been solved!", 25, 20);
                Font f = new Font("Courier", Font.BOLD, 14);
                    setFont(f);
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        buildWorld(g);
    }

    class TAdapter extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent e){

            if (solved) {
                return;
            }

            int key = e.getKeyCode();

            if(key == KeyEvent.VK_LEFT) {
                if (checkWallCollision(PlayerChar, LEFT_COLLISION)) {
                    return;
                }

                if (!checkBagCollision(LEFT_COLLISION)) {
                    PlayerChar.move(-SPACE, 0);
                } else {
                    return;
                }

            } else if(key == KeyEvent.VK_RIGHT) {
                if (checkBagCollision(RIGHT_COLLISION)) {
                    return;
                }

                PlayerChar.move(SPACE, 0);
            } else if (key == KeyEvent.VK_UP) {
                if (checkWallCollision(PlayerChar, TOP_COLLISION)) {
                    return;
                }

                if (checkBagCollision(TOP_COLLISION)) {
                    return;
                }

                PlayerChar.move(0, -SPACE);
            } else if (key == KeyEvent.VK_DOWN) {
                if (checkWallCollision(PlayerChar, BOTTOM_COLLISION)) {
                    return;
                }

                if (!checkBagCollision(BOTTOM_COLLISION)) {
                    PlayerChar.move(0, SPACE);
                } else {
                    return;
                }

            } else if (key == KeyEvent.VK_R) {
                restartStage();
            }
            repaint();
        }
    }

    private boolean checkWallCollision(User actor, int type) {
        if (type == LEFT_COLLISION) {
            for (int i = 0; i < obs.size(); i++) {
                Obstacle wall = (Obstacle) obs.get(i);

                if (actor.isLeftCollision(wall)) {
                    return true;
                }
            }
            return false;
        } else if (type == RIGHT_COLLISION) {
            for (int i = 0; i < obs.size(); i++) {
                Obstacle wall = (Obstacle) obs.get(i);

                if (actor.isRightCollision(wall)) {
                    return true;
                }
            }
            return false;
        } else if (type == BOTTOM_COLLISION) {
            for (int i = 0; i < obs.size(); i++) {
                Obstacle wall = (Obstacle) obs.get(i);

                if (actor.isBottomCollision(wall)) {
                    return true;
                }
            }
            return false;
        } else if (type == TOP_COLLISION) {
            for (int i = 0; i < obs.size(); i++) {
                Obstacle wall = (Obstacle) obs.get(i);

                if (actor.isTopCollision(wall)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    private boolean checkBagCollision(int type) {
        if (type == LEFT_COLLISION) {
            for (int i = 0; i < crates.size(); i++) {
                Crate bag = (Crate) crates.get(i);
                if (PlayerChar.isLeftCollision(bag)) {
                    for (int j = 0; j < crates.size(); j++) {
                        Crate item = (Crate) crates.get(j);
                        if (!bag.equals(item)) {
                            if (bag.isLeftCollision(item)) {
                                return true;
                            }
                        }
                        if (checkWallCollision(bag, LEFT_COLLISION)) {
                            return true;
                        }
                    }
                    bag.move(-SPACE, 0);
                    isSolved();
                }
            }
            return false;
        } else if (type == RIGHT_COLLISION) {
            for (int i = 0; i < crates.size(); i++) {
                Crate bag = (Crate) crates.get(i);
                if (PlayerChar.isRightCollision(bag)) {
                    for (int j = 0; j < crates.size(); j++) {
                        Crate item = (Crate) crates.get(j);
                        if (!bag.equals(item)) {
                            if (bag.isRightCollision(item)) {
                                return true;
                            }
                        }
                        if (checkWallCollision(bag, RIGHT_COLLISION)) {
                            return true;
                        }
                    }
                    bag.move(SPACE, 0);
                    isSolved();
                }
            }
            return false;
        } else if (type == TOP_COLLISION) {
            for (int i = 0; i < crates.size(); i++) {
                Crate bag = (Crate) crates.get(i);
                if (PlayerChar.isTopCollision(bag)) {
                    for (int j = 0; j < crates.size(); j++) {
                        Crate item = (Crate) crates.get(j);
                        if (!bag.equals(item)) {
                            if (bag.isTopCollision(item)) {
                                return true;
                            }
                        }
                        if (checkWallCollision(bag, TOP_COLLISION)) {
                            return true;
                        }
                    }
                    bag.move(0, -SPACE);
                    isSolved();
                }
            }
            return false;
        } else if (type == BOTTOM_COLLISION) {
            for (int i = 0; i < crates.size(); i++) {
                Crate bag = (Crate) crates.get(i);
                if (PlayerChar.isBottomCollision(bag)) {
                    for (int j = 0; j < crates.size(); j++) {
                        Crate item = (Crate) crates.get(j);
                        if (!bag.equals(item)) {
                            if (bag.isBottomCollision(item)) {
                                return true;
                            }
                        }
                        if (checkWallCollision(bag, BOTTOM_COLLISION)) {
                            return true;
                        }
                    }
                    bag.move(0, SPACE);
                    isSolved();
                }
            }
        }
        return false;
    }

    public void isSolved() {
        int num = crates.size();
        int compl = 0;

        for (int i = 0; i < num; i++) {
            Crate bag = (Crate) crates.get(i);

            for (int j = 0; j < num; j++) {
                SuitableLocation area = (SuitableLocation) SuitLo.get(j);

                if (bag.x() == area.x() && bag.y() == area.y()) {
                    compl += 1;
                }
            }
        }

        if (compl == num) {
            solved = true;
            repaint();
        }
    }

    public void restartStage() {
        SuitLo.clear();
        crates.clear();
        obs.clear();
        initWorld();
        if (solved) {
            solved = false;
        }
    }
}
