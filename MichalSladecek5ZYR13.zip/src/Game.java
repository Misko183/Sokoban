import javax.swing.JFrame;

public class Game extends JFrame {
    private static final long serialVersionUID = 1L;
    private final int OFFSET = 30;

    public Game() {
        InitUI();
    }

    public void InitUI() {
        Panel board = new Panel();
        add(board);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(board.getBoardWidth() + OFFSET, board.getBoardHeight() + 2 * OFFSET);
        setLocationRelativeTo(null);
        setTitle("Game");
    }

    public static void main(String[] args) {
        Game game = new Game();
        game.setVisible(true);
    }
}
