import javax.swing.ImageIcon;
import java.awt.Image;
import java.net.URL;

public class Crate extends User {

    public Crate(int i, int j) {
        super(i, j);
        URL locate = this.getClass().getResource("crate.png");
        ImageIcon ImgIcon = new ImageIcon(locate);
        Image img = ImgIcon.getImage();
        this.setImage(img);
    }

    public void move(int i, int j) {
        int mi = this.x() + i;
        int mj = this.y() + j;
        this.setX(mi);
        this.setY(mj);
    }
}
